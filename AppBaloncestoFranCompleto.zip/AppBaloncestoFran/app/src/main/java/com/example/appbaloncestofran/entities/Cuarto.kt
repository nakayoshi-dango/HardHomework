package com.example.appbaloncestofran.entities

import androidx.room.Entity
import androidx.room.Index
import androidx.room.ForeignKey
import androidx.room.PrimaryKey
import java.io.Serializable

@Entity(tableName = "cuarto",foreignKeys = [
    ForeignKey(
    entity = Partido::class,
    parentColumns = ["id"],
    childColumns = ["partidoId"],
    onDelete = ForeignKey.CASCADE)
],
    indices = [Index(value = ["partidoId"])]
)
data class Cuarto(
    @PrimaryKey(autoGenerate = true)
    var id:Long = 0,
    var cuarto:Int,
    var puntosLocal: Int,
    var puntosVisitante: Int,
    var partidoId: Long // foreign key para Partido
) : Serializable
