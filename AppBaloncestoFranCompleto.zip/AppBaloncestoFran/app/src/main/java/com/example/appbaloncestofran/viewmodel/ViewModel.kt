package com.example.appbaloncestofran.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.example.appbaloncestofran.database.BasketRepository
import com.example.appbaloncestofran.entities.Cuarto
import com.example.appbaloncestofran.entities.Partido
import kotlinx.coroutines.launch

class ViewModel(application: Application): AndroidViewModel(application) {
    private val repository: BasketRepository = BasketRepository(application)

    var allPartidos: LiveData<List<Partido>> = repository.getAllPartidos()

    init {
        viewModelScope.launch {
            repository.initializeDatabase()
        }
    }

    fun getAllPartidos() {
        this.allPartidos = repository.getAllPartidos()
    }

    fun addPartido(partido: Partido): LiveData<Long> {
        val partidoIdLiveData = MutableLiveData<Long>()
        viewModelScope.launch {
            val partidoId = repository.insertPartido(partido) // Espera que termine la inserción
            partidoIdLiveData.postValue(partidoId)   // Publica el ID después de la inserción
        }
        return partidoIdLiveData
    }

    fun addCuarto(cuarto: Cuarto): LiveData<Long> {
        val cuartoIdLiveData = MutableLiveData<Long>()
        viewModelScope.launch {
            val cuartoId = repository.insertCuarto(cuarto)
            cuartoIdLiveData.postValue(cuartoId)
        }
        return cuartoIdLiveData
    }

    fun getPartidoById(partidoID: Long): LiveData<Partido> {
        return repository.getPartidoById(partidoID)
    }

    fun getCuartosForPartido(partidoID: Long): LiveData<List<Cuarto>> {
        return repository.getCuartosForPartido(partidoID)
    }

    fun refreshAllPartidos() {
        viewModelScope.launch {
            repository.initializeDatabase()
        }
    }
}


