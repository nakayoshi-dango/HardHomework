package com.example.appbaloncestofran.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.appbaloncestofran.entities.Cuarto
import com.example.appbaloncestofran.entities.Partido
import com.example.appbaloncestofran.interfaces.CuartoDAO
import com.example.appbaloncestofran.interfaces.PartidoDAO

@Database(entities = [Partido::class, Cuarto::class], version = 1)
abstract class BasketDataBase : RoomDatabase() {

    abstract fun partidoDao(): PartidoDAO
    abstract fun cuartoDao(): CuartoDAO

    companion object {
        @Volatile
        private var INSTANCE: BasketDataBase? = null

        fun getInstance(context: Context): BasketDataBase {
            return INSTANCE ?: synchronized(this) {
                val tempInstance = INSTANCE
                if (tempInstance != null) {
                    return tempInstance
                }
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    BasketDataBase::class.java,
                    "basket-db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
