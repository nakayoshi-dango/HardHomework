package com.example.appbaloncestofran.database

import android.content.Context
import androidx.lifecycle.LiveData
import com.example.appbaloncestofran.entities.Cuarto
import com.example.appbaloncestofran.entities.Partido
import com.example.appbaloncestofran.interfaces.CuartoDAO
import com.example.appbaloncestofran.interfaces.PartidoDAO
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import androidx.lifecycle.MutableLiveData

class BasketRepository(private var context: Context) {

    private var partidoDao: PartidoDAO? = null
    private var cuartoDao: CuartoDAO? = null

    // Initialize the database and DAOs
    fun initializeDatabase() {
        CoroutineScope(Dispatchers.IO).launch {
            if (partidoDao == null || cuartoDao == null) {
                partidoDao = BasketDataBase.getInstance(context.applicationContext).partidoDao()
                cuartoDao = BasketDataBase.getInstance(context.applicationContext).cuartoDao()
            }
        }
    }

    // Return a partido's cuartos
    fun getCuartosForPartido(partidoId: Long): LiveData<List<Cuarto>> {
        return partidoDao?.getCuartosForPartido(partidoId) ?: MutableLiveData(emptyList())
    }

    // Get a partido by ID
    fun getPartidoById(partidoId: Long): LiveData<Partido> {
        return partidoDao?.getPartidoById(partidoId) ?: MutableLiveData(Partido(id = 0, nombreLocal = "", nombreVisitante = "", faltasLocal = 0, faltasVisitante = 0))
    }

    // Get all partidos
    fun getAllPartidos(): LiveData<List<Partido>> {
        return partidoDao?.getAllPartidos() ?: MutableLiveData(emptyList())
    }

    // Insert a partido
    suspend fun insertPartido(partido: Partido): Long {
        return partidoDao?.insertPartido(partido) ?: 0L
    }

    // Update a partido
    suspend fun updatePartido(partido: Partido) {
        partidoDao?.updatePartido(partido)
    }

    // Delete a partido
    suspend fun deletePartido(partido: Partido) {
        partidoDao?.deletePartido(partido)
    }

    // Get a cuarto by ID
    fun getCuartoById(cuartoId: Long): LiveData<Cuarto> {
        return cuartoDao?.getCuartoById(cuartoId) ?: MutableLiveData(Cuarto(id = 0, cuarto = 0, puntosLocal = 0, puntosVisitante = 0, partidoId = 0))
    }

    // Insert a cuarto
    suspend fun insertCuarto(cuarto: Cuarto): Long {
        return cuartoDao?.insertCuarto(cuarto) ?: 0L
    }

    // Update a cuarto
    suspend fun updateCuarto(cuarto: Cuarto) {
        cuartoDao?.updateCuarto(cuarto)
    }

    // Delete a cuarto
    suspend fun deleteCuarto(cuarto: Cuarto) {
        cuartoDao?.deleteCuarto(cuarto)
    }
}

