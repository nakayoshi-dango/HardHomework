package com.example.appbaloncestofran.interfaces

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.appbaloncestofran.entities.Cuarto

@Dao
interface CuartoDAO {
    @Insert
    suspend fun insertCuarto(cuarto: Cuarto):Long

    @Update
    suspend fun updateCuarto(cuarto: Cuarto)

    @Delete
    suspend fun deleteCuarto(cuarto: Cuarto)

    @Query("SELECT * FROM Cuarto WHERE id = :cuartoId")
    fun getCuartoById(cuartoId: Long): LiveData<Cuarto>
}