package com.example.appbaloncestofran

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.os.Bundle
import android.os.CountDownTimer
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.BaseAdapter
import android.widget.GridView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.Observer
import com.example.appbaloncestofran.R.layout.item_partido
import com.example.appbaloncestofran.databinding.ActivityBasketdexBinding
import com.example.appbaloncestofran.entities.Cuarto
import com.example.appbaloncestofran.entities.Partido
import com.example.appbaloncestofran.viewmodel.ViewModel

class Basketdex : AppCompatActivity() {

    private lateinit var binding: ActivityBasketdexBinding
    private lateinit var countDownTimer: CountDownTimer
    private var timeLeft: Long = 10 * 60 * 1000 // 10 minutos en milisegundos
    private var timerRunning = false
    private lateinit var nombreLocal: String
    private lateinit var nombreVisitante: String
    private var puntosLocal: IntArray = intArrayOf(0,0,0,0)
    private var puntosVisitante: IntArray = intArrayOf(0,0,0,0)
    private var faltasLocal: Int = 0
    private var faltasVisitante: Int = 0
    private var cuarto: Int = 1
    private lateinit var viewModel:ViewModel
    private var partidos: MutableList<Partido> = mutableListOf()
    private var partidoId: Long = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBasketdexBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        val view = binding.root
        setContentView(view)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        updateTimerText()
        viewModel = ViewModel(this.application)
        viewModel.refreshAllPartidos()
        viewModel.getAllPartidos()
        viewModel.allPartidos.observe(this) { updatedPartidos ->
            partidos.clear()
            partidos.addAll(updatedPartidos)
        }
        Log.d("Partidos","Número de partidos en la List<Partido> partidos: " + partidos.size)

        binding.nombreVisitanteE.addTextChangedListener(object : TextWatcher {

            override fun beforeTextChanged(charSequence: CharSequence?, start: Int, count: Int, after: Int) {
                // no necesario pero obligado a heredarlo
            }

            override fun onTextChanged(charSequence: CharSequence?, start: Int, before: Int, count: Int) {
                // para cambios en tiempo real mientras el usuario escribe
            }

            override fun afterTextChanged(editable: Editable?) {
                //para cuando termina de escribir el usuario
                //para cuando termina de escribir el usuario (en realidad funciona igual que el de arriba pero ni idea de por qué)
                val inputText = editable.toString()
                nombreVisitante = inputText
            }


        })

        binding.nombreLocalE.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(charSequence: CharSequence?, start: Int, count: Int, after: Int) {
                // no necesario pero obligado a heredarlo
            }

            override fun onTextChanged(charSequence: CharSequence?, start: Int, before: Int, count: Int) {
                // para cambios en tiempo real mientras el usuario escribe
            }

            override fun afterTextChanged(editable: Editable?) {
                //para cuando termina de escribir el usuario (en realidad funciona igual que el de arriba pero ni idea de por qué)
                val inputText = editable.toString()
                nombreLocal = inputText
            }
        })

        binding.spinnerCuarto.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            @SuppressLint("SetTextI18n")
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                //cambiamos la variable que indica el cuarto actual
                val selectedItem = binding.spinnerL.getItemAtPosition(position).toString()
                cuarto = selectedItem.toInt()
                binding.puntosLocal.text = puntosLocal[cuarto].toString()
                binding.puntosVisitante.text = puntosVisitante[cuarto].toString()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                // no necesario pero obligado a heredarlo
            }
        }

        binding.spinnerL.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                //Asignamos el número de faltas al equipo local
                val selectedItem = binding.spinnerL.getItemAtPosition(position).toString()
                faltasLocal = selectedItem.toInt()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                // no necesario pero obligado a heredarlo
            }
        }

        binding.spinnerV.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                //Asignamos el número de faltas al equipo visitante
                val selectedItem = binding.spinnerL.getItemAtPosition(position).toString()
                faltasVisitante = selectedItem.toInt()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                // no necesario pero obligado a heredarlo
            }
        }

        binding.LPlusOne.setOnClickListener {
            operation(binding.puntosLocal,1,true)
        }

        binding.LPlusTwo.setOnClickListener {
            operation(binding.puntosLocal,2,true)
        }

        binding.LPlusThree.setOnClickListener {
            operation(binding.puntosLocal,3,true)
        }

        binding.LMinusOne.setOnClickListener {
            operation(binding.puntosLocal,1,false)
        }

        binding.VPlusOne.setOnClickListener {
            operation(binding.puntosVisitante,1,true)
        }

        binding.VPlusTwo.setOnClickListener {
            operation(binding.puntosVisitante,2,true)
        }

        binding.VPlusThree.setOnClickListener {
            operation(binding.puntosVisitante,3,true)
        }

        binding.VMinusOne.setOnClickListener {
            operation(binding.puntosVisitante,1,false)
        }

        binding.startButton.setOnClickListener {
            startTimer()
        }

        binding.stopButton.setOnClickListener {
            stopTimer()
        }

        binding.guardar.setOnClickListener{
            try {
                val partido: Partido = Partido(
                    nombreLocal = nombreLocal,
                    nombreVisitante = nombreVisitante,
                    faltasLocal = faltasLocal,
                    faltasVisitante = faltasVisitante
                )

                viewModel.addPartido(partido).observe(this) { partidoId ->
                    if (partidoId != null) {
                        // Ahora que tenemos el partidoId, insertamos los Cuartos
                        val cuarto1 = Cuarto(
                            cuarto = 1,
                            puntosLocal = puntosLocal[0],
                            puntosVisitante = puntosVisitante[0],
                            partidoId = partidoId
                        )
                        val cuarto2 = Cuarto(
                            cuarto = 2,
                            puntosLocal = puntosLocal[1],
                            puntosVisitante = puntosVisitante[1],
                            partidoId = partidoId
                        )
                        val cuarto3 = Cuarto(
                            cuarto = 3,
                            puntosLocal = puntosLocal[2],
                            puntosVisitante = puntosVisitante[2],
                            partidoId = partidoId
                        )
                        val cuarto4 = Cuarto(
                            cuarto = 4,
                            puntosLocal = puntosLocal[3],
                            puntosVisitante = puntosVisitante[3],
                            partidoId = partidoId
                        )

                        // Insertamos los cuartos, observando cada uno de los resultados.
                        viewModel.addCuarto(cuarto1).observe(this) { cuartoId1 ->
                            Log.d("Cuarto", "Cuarto 1 insertado con ID: $cuartoId1")
                        }
                        viewModel.addCuarto(cuarto2).observe(this) { cuartoId2 ->
                            Log.d("Cuarto", "Cuarto 2 insertado con ID: $cuartoId2")
                        }
                        viewModel.addCuarto(cuarto3).observe(this) { cuartoId3 ->
                            Log.d("Cuarto", "Cuarto 3 insertado con ID: $cuartoId3")
                        }
                        viewModel.addCuarto(cuarto4).observe(this) { cuartoId4 ->
                            Log.d("Cuarto", "Cuarto 4 insertado con ID: $cuartoId4")
                        }

                        // Mostrar mensaje de éxito con el partidoId
                        Toast.makeText(
                            applicationContext,
                            "Partido guardado con ID: $partidoId",
                            Toast.LENGTH_SHORT
                        ).show()

                        // Reiniciar la cuenta atrás después de persistir
                        stopTimer()
                        timeLeft = 10 * 60 * 1000
                        updateTimerText()

                        // Actualizar la lista de partidos
                        viewModel.allPartidos.observe(this) { updatedPartidos ->
                            partidos.clear()
                            partidos.addAll(updatedPartidos)
                        }
                        Log.d("Partidos","Número de partidos en la List<Partido> partidos después de guardar: " + partidos.size)
                    }
                }

            } catch (e: Exception) {
                Log.e(e.message,e.stackTraceToString())
                throw e
            }
        }

        binding.cargar.setOnClickListener {
            //crear un dialog con todos los partidos de la base de datos en una tabla con 4 columnas: partidoId, nombreLocal, nombreVisitante, fecha
            viewModel.getAllPartidos()
            viewModel.allPartidos.observe(this) { updatedPartidos ->
                partidos.clear()
                partidos.addAll(updatedPartidos)
                Log.e("Partidos", "Número de partidos en la lista durante CARGAR: ${partidos.size}")
                showPartidosDialog()
            }
        }

    }

    private fun cargarPartido(partido: Partido) {
        viewModel.getCuartosForPartido(partidoId).observe(this) { cuartos ->
        this.nombreLocal = partido.nombreLocal
        this.nombreVisitante = partido.nombreVisitante
        if (cuartos.isEmpty()){
            this.puntosLocal = intArrayOf(0,0,0,0)
            this.puntosVisitante = intArrayOf(0,0,0,0)
        } else {
            this.puntosLocal = intArrayOf(cuartos[0].puntosLocal,cuartos[1].puntosLocal,cuartos[2].puntosLocal,cuartos[3].puntosLocal)
            this.puntosVisitante = intArrayOf(cuartos[0].puntosVisitante,cuartos[1].puntosVisitante,cuartos[2].puntosVisitante,cuartos[3].puntosVisitante)
        }
        this.faltasLocal = partido.faltasLocal
        this.faltasVisitante = partido.faltasVisitante
        this.cuarto = 1
        binding.nombreLocalE.setText(this.nombreLocal)
        binding.nombreVisitanteE.setText(this.nombreVisitante)
        binding.puntosLocal.setText(this.puntosLocal[cuarto-1].toString())
        binding.puntosVisitante.setText(this.puntosVisitante[cuarto-1].toString())
        if (this.faltasLocal>0) {
            binding.spinnerL.setSelection(this.faltasLocal-1)
        } else {
            binding.spinnerL.setSelection(0)
        }
        if (this.faltasVisitante>0) {
            binding.spinnerV.setSelection(this.faltasVisitante-1)
        } else {
            binding.spinnerV.setSelection(0)
        }
        binding.spinnerCuarto.setSelection(this.cuarto-1)
        }
    }

    private fun showPartidosDialog(){
        // Crear un adapter para el GridView
        val adapter = object : BaseAdapter() {
            override fun getCount(): Int {
                return partidos.size
            }

            override fun getItem(position: Int): Any {
                return partidos[position]
            }

            override fun getItemId(position: Int): Long {
                return partidos[position].id.toLong()
            }

            @SuppressLint("SetTextI18n")
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val partido = partidos[position]
                val view = layoutInflater.inflate(item_partido, parent, false)
                val partidoId = view.findViewById<TextView>(R.id.textViewPartidoId)
                val nombreLocal = view.findViewById<TextView>(R.id.textViewNombreLocal)
                val nombreVisitante = view.findViewById<TextView>(R.id.textViewNombreVisitante)
                val fecha = view.findViewById<TextView>(R.id.textViewFecha)

                partidoId.text = partido.id.toString()
                nombreLocal.text = partido.nombreLocal
                nombreVisitante.text = partido.nombreVisitante
                fecha.text = partido.fecha.toString()

                return view
            }
        }

        // creando el dialog
        val dialogBuilder = AlertDialog.Builder(this)
        val dialogView = layoutInflater.inflate(R.layout.dialog_partidos, null)
        val gridView = dialogView.findViewById<GridView>(R.id.gridViewPartidos)
        gridView.adapter = adapter

        //listener de fila seleccionada
        gridView.setOnItemClickListener { _, _, position, _ ->
            val selectedPartido = partidos[position]
            partidoId = selectedPartido.id

            // Mostramos un Toast para confirmar que el partido se ha seleccionado
            Toast.makeText(this, "Partido seleccionado: $partidoId", Toast.LENGTH_SHORT).show()

            // Ahora obtenemos el partido seleccionado y cargamos los datos
            viewModel.getPartidoById(partidoId).observe(this) { partido ->
                partido?.let {
                    cargarPartido(it)
                }
            }
        }

        // Mostrar el dialog
        dialogBuilder.setView(dialogView)
        dialogBuilder.setTitle("Selecciona un Partido")
        dialogBuilder.setPositiveButton("Cerrar") { dialog, _ -> dialog.dismiss() }
        dialogBuilder.create().show()
    }

    @SuppressLint("SetTextI18n")
    private fun operation(lv:android.widget.TextView, puntos:Int, sum:Boolean) {
        val tmp = lv.text.toString().toIntOrNull() ?: 0
        val r = if (sum) {
            tmp + puntos
        } else {
            if (tmp - puntos > 0) {
                tmp - puntos
            } else {
                0
            }
        }
        lv.setText(r.toString())
        if (lv == binding.puntosLocal){
            puntosLocal[cuarto]=r
        } else {
            puntosVisitante[cuarto]=r
        }
    }

    private fun startTimer() {
        if (timerRunning) return

        countDownTimer = object : CountDownTimer(timeLeft, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                timeLeft = millisUntilFinished
                updateTimerText()
            }

            override fun onFinish() {
                timerRunning = false
                Toast.makeText(this@Basketdex,"Time's up!",Toast.LENGTH_SHORT).show()
                timeLeft = 10 * 60 * 1000
            }
        }.start()

        timerRunning = true
    }

    private fun stopTimer() {
        if (::countDownTimer.isInitialized){
            countDownTimer.cancel()
            timerRunning = false
        }
    }

    @SuppressLint("DefaultLocale")
    private fun updateTimerText() {
        val minutes = (timeLeft / 1000) / 60
        val seconds = (timeLeft / 1000) % 60
        val formattedTime = String.format("%02d:%02d", minutes, seconds)
        binding.contador.text = formattedTime
    }
}