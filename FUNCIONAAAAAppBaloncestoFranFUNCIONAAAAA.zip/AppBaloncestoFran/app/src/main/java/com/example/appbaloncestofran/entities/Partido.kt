package com.example.appbaloncestofran.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable
import java.time.LocalDate

@Entity(tableName = "partido")
data class Partido(
    @PrimaryKey(autoGenerate = true)
    var id:Long = 0,
    val fecha: String = LocalDate.now().toString(),
    val nombreLocal: String,
    val nombreVisitante: String,
    val faltasLocal: Int,
    val faltasVisitante: Int,
    ): Serializable