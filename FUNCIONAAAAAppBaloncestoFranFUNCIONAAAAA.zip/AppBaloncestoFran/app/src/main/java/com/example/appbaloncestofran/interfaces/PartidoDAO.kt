package com.example.appbaloncestofran.interfaces

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.appbaloncestofran.entities.Cuarto
import com.example.appbaloncestofran.entities.Partido

@Dao
interface PartidoDAO {


    @Query("SELECT * FROM Partido WHERE id = :partidoId")
    fun getPartidoById(partidoId: Long): LiveData<Partido>

    @Query("SELECT * FROM Partido")
    fun getAllPartidos(): LiveData<List<Partido>>

    @Insert
    suspend fun insertPartido(partido: Partido): Long

    @Update
    suspend fun updatePartido(partido: Partido)

    @Delete
    suspend fun deletePartido(partido: Partido)

    @Query("SELECT * FROM Cuarto WHERE partidoId = :partidoId")
    fun getCuartosForPartido(partidoId: Long): LiveData<List<Cuarto>>

}